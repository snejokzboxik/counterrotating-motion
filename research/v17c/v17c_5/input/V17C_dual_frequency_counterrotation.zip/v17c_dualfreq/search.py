import numpy as np,csv,pathlib
from numba import njit
from concurrent.futures import ThreadPoolExecutor
P=pathlib.Path(__file__).parent
def load():
 d={int(x['k']):complex(float(x['re']),float(x['im'])) for x in csv.DictReader(open(P/'geometry_spectra.csv')) if float(x['a_D'])==.05 and float(x['B_D'])==1.1 and x['pattern']=='mixed6'}
 terms=[]
 for j,k0 in enumerate([2,-4]):
  for k,v in d.items():
   if (k-k0)%12==0 and abs(v)>1e-12: terms.append((j,k,v/d[k0]))
 return np.array([x[0] for x in terms]),np.array([x[1] for x in terms]),np.array([x[2] for x in terms])
@njit(cache=True,nogil=True)
def rhs(t,y,p,js,ks,cs):
 A,B,nu,beta,s,C,lam,lam2=p[:8]
 dy=np.empty(12); dx=y[0]-y[6];ddy=y[1]-y[7];dz=y[2]-y[8];cf=C/max(dx*dx+ddy*ddy+dz*dz,1e-20)**1.5
 ph1=A*complex(np.cos(t),-np.sin(t));ph2=B*complex(np.cos(nu*t),-np.sin(nu*t))
 for i in range(2):
  b=6*i;x=y[b]; yy=y[b+1];z=y[b+2];q=1. if i==0 else s;l=lam if i==0 else lam2
  zz=complex(x,yy);fx=0.;fy=0.
  for h in range(len(ks)):
   k=ks[h];g=1 if k>0 else -1;n=abs(k);a=(ph1 if js[h]==0 else ph2)*cs[h]*n*((zz if g==1 else zz.conjugate())**(n-1));fx-=a.real;fy+=g*a.imag
  sign=1. if i==0 else -1.
  if len(p)>8:l*=1+p[8]*np.sqrt(y[b+3]**2+y[b+4]**2+y[b+5]**2)
  dy[b]=y[b+3];dy[b+1]=y[b+4];dy[b+2]=y[b+5]
  dy[b+3]=q*(fx+beta*x+sign*cf*dx)-l*y[b+3]
  dy[b+4]=q*(fy+beta*yy+sign*cf*ddy)-l*y[b+4]
  dy[b+5]=q*(-2*beta*z+sign*cf*dz)-l*y[b+5]
 return dy
@njit(cache=True,nogil=True)
def run(y,p,js,ks,cs,N,steps,stride):
 dt=2*np.pi/steps;t=0.;out=np.empty((N//stride+2,13));out[0,0]=0;out[0,1:]=y;idx=1
 for it in range(N*steps):
  k1=rhs(t,y,p,js,ks,cs);k2=rhs(t+dt/2,y+dt*k1/2,p,js,ks,cs);k3=rhs(t+dt/2,y+dt*k2/2,p,js,ks,cs);k4=rhs(t+dt,y+dt*k3,p,js,ks,cs);y=y+dt/6*(k1+2*k2+2*k3+k4);t=(it+1)*dt
  if max(y[0]**2+y[1]**2,y[6]**2+y[7]**2)>1 or max(abs(y[2]),abs(y[8]))>2 or not np.all(np.isfinite(y)):
   out[idx,0]=t;out[idx,1:]=y;return out[:idx+1],False
  if (it+1)%(steps*stride)==0:
   out[idx,0]=t;out[idx,1:]=y;idx+=1
 return out[:idx],True

def init(A,ratio,nu,r1,r2,lam,C,theta=1.2,z=.02):
 B=A*ratio; F=lambda r:4*A*A/(1+lam*lam)+48*B*B*r**4/(nu*nu+lam*lam)
 s=F(r1)/F(r2);beta=F(r1)
 w=lambda r,q:q*q*(4*A*A/(1+lam*lam)-48*B*B*r**4/(nu*(nu*nu+lam*lam)))
 y=np.array([r1,0.,z,0.,r1*w(r1,1),0.,r2*np.cos(theta),r2*np.sin(theta),-z,-r2*np.sin(theta)*w(r2,s),r2*np.cos(theta)*w(r2,s),0.])
 return y,np.array([A,B,nu,beta,s,C,lam,lam])
def stats(out):
 x=out[:,1:];a=np.unwrap(np.arctan2(x[:,[1,7]],x[:,[0,6]]),axis=0);r=np.hypot(x[:,[0,6]],x[:,[1,7]]);cut=np.linspace(len(x)//2,len(x)-1,4,dtype=int);turn=np.diff(a[cut],axis=0)/(2*np.pi)
 return turn,r[cut[0]:].min(0),r[cut[0]:].max(0)
if __name__=='__main__':
 js,ks,cs=load();mask=abs(ks)<=22;js,ks,cs=js[mask],ks[mask],cs[mask];cases=[]
 for A in [.035,.055,.075]:
  for ratio in [2.5,3.5]:
   for nu in [1.4142135623730951,1.73]:
    for C in [0.,1e-5,5e-5]:cases.append(init(A,ratio,nu,.30,.58,.012,C))
 run(*cases[0],js,ks,cs,1,16,1)
 def go(i):
  y,p=cases[i];o,ok=run(y,p,js,ks,cs,1800,40,2);w,m,M=stats(o);print(i,ok,np.round(w,3).tolist(),np.round(m,3),np.round(M,3),flush=True);return i,o,ok
 with ThreadPoolExecutor(max_workers=6) as ex: results=list(ex.map(go,range(len(cases))))
 np.savez_compressed(P/'scout.npz',param=np.array([c[1] for c in cases]),init=np.array([c[0] for c in cases]),retained=np.array([ok for i,o,ok in results]),**{f'case{i}':o for i,o,ok in results})
