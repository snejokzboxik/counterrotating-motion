from search import *
js=np.array([0,1]);ks=np.array([2,-4]);cs=np.ones(2,complex)
cases=[]
for A in [.035,.055,.075]:
 for ratio in [2.5,3.5]:
  for nu in [np.sqrt(2),1.73]:
   for C in [1e-7,1e-6,1e-5]:cases.append(init(A,ratio,nu,.3,.58,.012,C))
run(*cases[0],js,ks,cs,1,16,1)
def go(i):
 y,p=cases[i];o,ok=run(y,p,js,ks,cs,2200,48,2);w,m,M=stats(o);print(i,ok,np.round(w,3).tolist(),np.round(m,3),np.round(M,3),flush=True);return i,o,ok
with ThreadPoolExecutor(max_workers=6) as ex: results=list(ex.map(go,range(len(cases))))
np.savez_compressed(P/'ideal.npz',param=np.array([c[1] for c in cases]),init=np.array([c[0] for c in cases]),retained=np.array([ok for i,o,ok in results]),**{f'case{i}':o for i,o,ok in results})
