from search import *
from scipy.integrate import solve_ivp
import json
v=np.load(P/'verification_coeffs.npz');j,k,c=[v[a] for a in ['family','k','coeff']];b=np.load(P/'base128.npz');p=b['p'];o=b['trajectory'];i=14000;start=o[i,0];y=o[i,1:13];t=o[i:i+201,0]; sol=solve_ivp(lambda t,x:rhs(t,x,p,j,k,c),(t[0],t[-1]),y,t_eval=t,method='DOP853',rtol=2e-11,atol=2e-13,max_step=.20);assert sol.success
x=sol.y.T;ref=o[i:i+201,1:13];a=np.unwrap(np.arctan2(x[:,[1,7]],x[:,[0,6]]),axis=0);ar=np.unwrap(np.arctan2(ref[:,[1,7]],ref[:,[0,6]]),axis=0);d=dict(rf_periods=200,max_state_difference=float(np.max(abs(x-ref))),DOP853_turns=((a[-1]-a[0])/(2*np.pi)).tolist(),RK4_turns=((ar[-1]-ar[0])/(2*np.pi)).tolist(),nfev=sol.nfev)
np.savez_compressed(P/'dop853.npz',t=t,trajectory=x,reference=ref,p=p);print(d);(P/'dop853.json').write_text(json.dumps(d,indent=2))
# coupling test, same initial setup and same high-resolution spectrum
for C in [0.,1e-6,2e-5]:
 pp=p.copy();pp[5]=C;out,ok=run(b['initial'],pp,j,k,c,3500,64,1);w,m,M=stats(out);a=np.unwrap(np.arctan2(out[:,[2,8]],out[:,[1,7]]),axis=0);co=out[:,1:4]-out[:,7:10];dist=np.linalg.norm(co,axis=1);f=(a[-1]-a[len(a)//2])/(out[-1,0]-out[len(a)//2,0]); print('C',C,ok,f,w,dist.min(),flush=True);np.savez_compressed(P/f'coupling_{C:.0e}.npz',trajectory=out,p=pp,retained=ok)
