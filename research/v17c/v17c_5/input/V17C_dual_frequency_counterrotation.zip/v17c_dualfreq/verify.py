from search import *
from multielectrode import geom
from scipy.integrate import solve_ivp
import json
j,k,c,dat=geom(24,48)
np.savez(P/'verification_coeffs.npz',family=j,k=k,coeff=c)
a=np.load(P/'ideal.npz');y0=a['init'][26];p0=a['param'][26];print('params',p0,'initial',y0,flush=True)
# integrate at RF resolution and accumulate independent work quadrature in RK stages
@njit(cache=True,nogil=True)
def power(y,dy,p):
 A,B,nu,beta,s,C,lam,lam2=p[:8];d=y[:3]-y[6:9];cf=C/max(np.dot(d,d),1e-20)**1.5
 out=np.zeros(4)
 for i in range(2):
  b=i*6;v=y[b+3:b+6];q=1. if i==0 else s;l=lam if i==0 else lam2
  if len(p)>8:l*=1+p[8]*np.sqrt(np.dot(v,v))
  x=y[b:b+3];st=q*np.array([beta*x[0],beta*x[1],-2*beta*x[2]])+q*(1. if i==0 else -1.)*cf*d
  out[2*i]=np.dot(v,dy[b+3:b+6]-st+l*v)/q
  out[2*i+1]=l*np.dot(v,v)/q
 return out
@njit(cache=True,nogil=True)
def integrate(y,p,j,k,c,N,steps):
 dt=2*np.pi/steps;t=0.;out=np.empty((N+1,17));out[0,0]=0;out[0,1:13]=y;w=np.zeros(4);out[0,13:]=w
 for it in range(N*steps):
  k1=rhs(t,y,p,j,k,c);u=y+dt*k1/2;k2=rhs(t+dt/2,u,p,j,k,c);v=y+dt*k2/2;k3=rhs(t+dt/2,v,p,j,k,c);z=y+dt*k3;k4=rhs(t+dt,z,p,j,k,c)
  w+=dt/6*(power(y,k1,p)+2*power(u,k2,p)+2*power(v,k3,p)+power(z,k4,p));y=y+dt/6*(k1+2*k2+2*k3+k4);t=(it+1)*dt
  if max(y[0]**2+y[1]**2,y[6]**2+y[7]**2)>1 or max(abs(y[2]),abs(y[8]))>2 or not np.all(np.isfinite(y)):return out[:it//steps+1],False
  if (it+1)%steps==0:out[(it+1)//steps,0]=t;out[(it+1)//steps,1:13]=y;out[(it+1)//steps,13:]=w
 return out,True
# full work check uses total K+DC+Coulomb, no RF potential because RF mechanical power included

def energy(y,p):
 b=p[3];s=p[4];C=p[5];x=y[...,0:3];z=y[...,6:9];return .5*np.sum(y[...,3:6]**2,axis=-1)+.5/s*np.sum(y[...,9:12]**2,axis=-1)+b*(x[...,2]**2+z[...,2]**2-.5*(np.sum(x[...,:2]**2,axis=-1)+np.sum(z[...,:2]**2,axis=-1)))+C/np.linalg.norm(x-z,axis=-1)

def diag(o,p):
 y=o[:,1:13];t=o[:,0];a=np.unwrap(np.arctan2(y[:,[1,7]],y[:,[0,6]]),axis=0);r=np.hypot(y[:,[0,6]],y[:,[1,7]]);start=min(2000,len(o)//3);cuts=np.linspace(start,len(o)-1,4,dtype=int);w=np.diff(a[cuts],axis=0)/(2*np.pi);d=np.linalg.norm(y[:,0:3]-y[:,6:9],axis=1);E=energy(y,p);work=o[:,13:];err=E-E[0]-(work[:,0]+work[:,2]-work[:,1]-work[:,3]);return dict(cuts_rf=cuts.tolist(),turns=w.tolist(),freq_over_RF=((a[-1]-a[start])/(t[-1]-t[start])).tolist(),rmin=r[start:].min(0).tolist(),rmax=r[start:].max(0).tolist(),rmean=r[start:].mean(0).tolist(),min_distance=float(d[start:].min()),work_late=(work[-1]-work[start]).tolist(),energy_late=float(E[-1]-E[start]),balance_max=float(np.max(abs(err))),max_z=float(abs(y[start:,[2,8]]).max()))
if __name__=='__main__':
 integrate(y0,p0,j,k,c,1,16)
 tasks=[('base64',y0,p0,15000,64),('base128',y0,p0,15000,128),('perturb',y0*np.array([1.01,1,1,1,1,1,1.01,1.01,1,1,1,1]),p0,12000,64),('oseen',y0,np.r_[p0,0.5],12000,64)]
 def go(task):
  name,y,p,N,step=task;o,ok=integrate(y,p,j,k,c,N,step);d=diag(o,p);d.update(retained=bool(ok),p=p.tolist(),initial=y.tolist(),steps=step);print(name,d,flush=True);np.savez_compressed(P/f'{name}.npz',trajectory=o,p=p,initial=y);return name,d
 with ThreadPoolExecutor(max_workers=4) as ex:res=dict(ex.map(go,tasks))
 (P/'verification.json').write_text(json.dumps(res,indent=2))
